﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Creature : MonoBehaviour {

	// Variaveis de movimentacao
	private float speed = 12,angle = 11f;
	private Vector2 direction = Vector2.zero;

	//SENSORES
	private float raycastMaxDist = 1f, rayCloseDistRate = 0.3f, rayMediumDistRate = 0.65f;
	private RaycastHit2D frontHit;
	private RaycastHit2D leftHit;
	private RaycastHit2D rightHit;

	// Pontuacao/ variaveis de suporte para o AG
	public int pontuation;
	public bool isAlive = true;
	public GameObject lastMileHit;
	public float lastMileDist = 0;

	private string  curMilestones = "milestone (1)";

	private GeneticAlgorithm gA;
	private int curTrack = 0;


	// Use this for initialization
	void Start () {
		pontuation = 0;
		gA = (GeneticAlgorithm)GameObject.Find ("GA").GetComponent (typeof(GeneticAlgorithm));

	}

	// Update is called once per frame
	void Update () {
		// Controle manual desativado
		//GetInput ();
		//Move ();
		// Mantem sensores ativos
		checkRaycast ();

		//int checkTrack = gA.track;
		//if(checkTrack != curTrack){
		//	curTrack = checkTrack;
		//	curMilestones = "milestone ("+(curTrack+1)+")";
		//}
	}


	// ===================== Colisoes ============================
	// Reacoes ao colidir com um objeto
	void OnCollisionEnter2D(Collision2D coll){

		// Colisao com um Milestone = pontuacao
		if (coll.gameObject.transform.IsChildOf (GameObject.Find (curMilestones).transform)) {
			// Pontua o individuo
			pontuation++;
			// Desativa o milestone
			coll.gameObject.GetComponent<SpriteRenderer> ().enabled = false;
			coll.gameObject.GetComponent<BoxCollider2D> ().enabled = false;
			//lastMileHit = coll.gameObject;
		} else  {	
			//lastMileDist = lastMileHit.transform.
			isAlive = false; // 'Mata' este individuo
		}
			
	}
	// ===========================================================

	// ================= controle manual ========================
	// move o robo
	public void Move(){
		transform.Translate (direction*speed*Time.deltaTime);
	}
	// recebe comando do teclado
	public void GetInput(){

		if (Input.GetKey (KeyCode.W)) {
			direction = Vector2.up;
		} else {
			direction = Vector2.zero;
		} 

		if(Input.GetKey(KeyCode.A)){
			transform.Rotate(0,0,angle);
		}
		if(Input.GetKey(KeyCode.D)){
			transform.Rotate(0,0,-angle);
		}
	}
	// ===========================================================



	// ====================================================================================================================
	// Determina o movimento do individuo
	public void setMove(float dir){

		transform.Translate (Vector2.up*speed*Time.deltaTime);
	
		transform.Rotate(0,0,dir);


		//if (dir == 1) { // virar para a esquerda
			//transform.Rotate(0,0,angle);
		//}
		//if (dir == 2) { // virar para as direita
			//transform.Rotate(0,0,-angle);
		//}
			
	}
		
	// Retorna um valor inteiro respectivo a detecção dos sensores
	public int checkSensors(){
		int s = 0;

		if (leftHit.collider && !leftHit.collider.gameObject.transform.IsChildOf (GameObject.Find (curMilestones).transform)
		    && !leftHit.collider.gameObject.transform.IsChildOf (GameObject.Find ("chegada").transform)) { // s1 

			if (leftHit.distance < raycastMaxDist * rayCloseDistRate)
				s += 1;
			else if (leftHit.distance < raycastMaxDist * rayMediumDistRate)
				s += 2;
			else
				s += 3;
		}

		if (frontHit.collider && !frontHit.collider.gameObject.transform.IsChildOf (GameObject.Find (curMilestones).transform)
		    && !frontHit.collider.gameObject.transform.IsChildOf (GameObject.Find ("chegada").transform)) { // s2

			if (frontHit.distance < raycastMaxDist * rayCloseDistRate)
				s += 4;
			else if (frontHit.distance < raycastMaxDist * rayMediumDistRate)
				s += 8;
			else
				s += 12;
		}

		if (rightHit.collider && !rightHit.collider.gameObject.transform.IsChildOf (GameObject.Find (curMilestones).transform)
		    && !rightHit.collider.gameObject.transform.IsChildOf (GameObject.Find ("chegada").transform)) { // s3

			if (rightHit.distance < raycastMaxDist * rayCloseDistRate)
				s += 16;
			else if (rightHit.distance < raycastMaxDist * rayMediumDistRate)
				s += 32;
			else
				s += 48;
		}

		// 0 = nenhum, 1,2,3 = sensor esquerdo; 4,8,12 = sensor frontal; 5,6,7,9,10,11,13,1	4,15= sensor esquedo+frontal;
		// 16,32,48 = sensor direito; 17,18,19,33,34,35,49,50,51 = sensor direito+frontal
	
		return s;
	}
	// ========================================	============================================================================


	// ======================================= Editor dos sensores ========================================================
	// verificador de colisoes
	public void checkRaycast(){

		// vetor auxiliar para encontrar a direcao para qual o obj esta olhando
		Vector3 frontRay; 
		frontRay = transform.up;
		frontRay.Normalize ();

		//RectTransform rct = (RectTransform)gameObject.transform;
		float size = 0.25f;
		Debug.Log ("Size = "+size);
		Vector3 frontRayAdd = frontRay*size;

		size = 0.23f;

		Vector3 leftRay; 
		leftRay = transform.up+(-1*transform.right);
		leftRay.Normalize ();
		Vector3 leftRayAdd = leftRay*size;

		Vector3 rightRay; 
		rightRay = transform.up+transform.right;
		rightRay.Normalize ();
		Vector3 rightRayAdd = rightRay*size;

		// raio de tector de colisoes
		frontHit = Physics2D.Raycast (transform.position+frontRayAdd,frontRay,raycastMaxDist);
		leftHit = Physics2D.Raycast (transform.position+leftRayAdd,leftRay,raycastMaxDist);
		rightHit = Physics2D.Raycast (transform.position+rightRayAdd,rightRay,raycastMaxDist);

		// Desenha o raio frontal na tela com azul quando detectar algum obj (!frontHit.transform.Equals(this.transform)
		if (frontHit.collider) {
			Color aux = Color.green;
			if (frontHit.distance < raycastMaxDist * rayCloseDistRate)
				aux = Color.red;
			else if (frontHit.distance < raycastMaxDist * rayMediumDistRate)
				aux = Color.yellow;

			Debug.DrawRay (transform.position + frontRayAdd, frontRay * raycastMaxDist, aux);
		} else {
			Debug.DrawRay (transform.position + frontRayAdd, frontRay * raycastMaxDist, Color.gray);
		}
		// Desenha  o raio esquerdo
		if (leftHit.collider) {
			Color aux = Color.green;
			if (leftHit.distance < raycastMaxDist * rayCloseDistRate)
				aux = Color.red;
			else if (leftHit.distance < raycastMaxDist * rayMediumDistRate)
				aux = Color.yellow;

			Debug.DrawRay (transform.position + leftRayAdd, leftRay * raycastMaxDist, aux);

		} else {
			Debug.DrawRay (transform.position + leftRayAdd, leftRay * raycastMaxDist, Color.gray);
		}
		// Desenha o raio direito
		if (rightHit.collider) {
			Color aux = Color.green;
			if (frontHit.distance < raycastMaxDist * rayCloseDistRate)
				aux = Color.red;
			else if (frontHit.distance < raycastMaxDist * rayMediumDistRate)
				aux = Color.yellow;
			Debug.DrawRay (transform.position + rightRayAdd, rightRay * raycastMaxDist, aux);
		} else {
			Debug.DrawRay (transform.position + rightRayAdd, rightRay * raycastMaxDist, Color.gray);
		}

	}
	// ====================================================================================================================

}
