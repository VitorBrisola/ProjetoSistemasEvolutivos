﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class GeneticAlgorithm : MonoBehaviour {

	// Variaveis de controle dos individuos
	private GameObject indv,deadIndv;
	private float[][] indvGen,bestOfAll;
	private int[] fit; // vetor com a pontuacao de cada individuo
	private Creature c;

	// Variaveis de controle do AG
	private int numOfGenes = 64,genRange = 20,numOfIndv = 10,curIndv = 0,numOfGenerations = 0, numOfMutGen = 2, maxOfGenerations = 1000;
	private float mutationTax = .5f;

	// Variaveis de controle da simulacao
	private bool runGeneration, enterIndivChange = true,enterSelection = true,enterCrossover = false,enterMutation = false,enterTrackChange = true,enterGenerationChange = true;
	public int track = 0, numOfTracks = 2;
	private string  curMilestones = "milestone (1)";

	// variaveis de suporte a simulacao
	private System.Random rand;
	private StreamWriter bestFile, popBestFile, popAvgFile;

	private bool pause = false;

	// Use this for initialization
	void Start () {

		activateTrack (1,false);
		activateTrack (0,true);

		bestOfAll = new float[2][];
		bestOfAll[0] = new float[numOfGenes]; // genes do melhor de todos
		bestOfAll[1] = new float[1]; // fitness do melhor de todos
		bestOfAll[1][0] = -1; // inicializando pontuacao do melhor de todos

		fit = new int[numOfIndv];
		resetFit ();

		rand = new System.Random();
		bestFile= new StreamWriter (Application.dataPath + "/MelhorDeTodos.txt");
		popBestFile = new StreamWriter (Application.dataPath + "/MelhorDaGeracao.txt");
		popAvgFile = new StreamWriter (Application.dataPath + "/MediaDaGeracao.txt");

		// inicializa individuo
		indv = Instantiate (GameObject.Find ("creature"));
		indv.GetComponent<SpriteRenderer> ().enabled = true;
		indv.GetComponent<BoxCollider2D> ().enabled = true;
		indv.GetComponent<Creature>().enabled = true;
		c = (Creature)indv.GetComponent (typeof(Creature));

		// Inicializa AG
		initPop ();
		runGeneration = true;

	}

	// Update is called once per frame
	void Update () {

		if(!pause){	
			if (runGeneration) { // roda simulacao da geracao atual
				
				// movimenta individuo
				move (indv, curIndv);

				// troca de individuos
				if (!(c.isAlive) && enterIndivChange) { 
					changeIndv ();
				}

				// Controle de individuos por geracao
				if (curIndv > (numOfIndv - 2)) { 
					runGeneration = false;
				}

			//} else if (enterTrackChange) {
				//changeTrack ();
			} else if (enterGenerationChange) { // roda AG sobre ultima pop
				

				if (enterSelection) { 
					selection ();
				} else if (enterCrossover) {
					crossover ();
				} else if (enterMutation) {
					mutation ();
				}
			
			}
		}



	}


	void OnApplicationQuit(){
		bestFile.Close ();
		popBestFile.Close ();
		popAvgFile.Close ();
	}

	void OnGUI(){
		GUI.Label(new Rect(10,10,80,100)," Indivuo = " + (curIndv+1));
		GUI.Label(new Rect(100,10,80,100)," Geração = " + (numOfGenerations+1));
		GUI.Label(new Rect(200,10,100,100)," Pontuação = " + (fit[curIndv]+c.pontuation));
		GUI.Label(new Rect(300,10,150,100)," Melhor de todos = " + bestOfAll[1][0]);

	}

	public void resetFit(){
		for (int i = 0; i < numOfIndv; i++) {
			fit [i] = 0;
		}
	}


	// Reinicializa variaveis de controle do AG
	public void resetAll(){
		if (numOfGenerations < maxOfGenerations) {
			numOfGenerations++;
			curIndv = 0;
			runGeneration = true;
			enterIndivChange = true;
			enterTrackChange = true;
			enterSelection = true;
			enterCrossover = false;
			enterMutation = false;
		} 
	}

	// Reinicializa millestones
	public void resetMillestones(){
		foreach (Transform child in GameObject.Find (curMilestones).transform){
			child.GetComponent<SpriteRenderer> ().enabled = true;
			child.GetComponent<BoxCollider2D> ().enabled = true;
		}
	
	}

	public void activateTrack(int t,bool activation){
		string curM = "milestone (" + (t + 1) + ")";
		foreach (Transform child in GameObject.Find (curM).transform){
			child.GetComponent<SpriteRenderer> ().enabled = activation;
			child.GetComponent<BoxCollider2D> ().enabled = activation;
		}
		string curTrackName = "Track" + (t + 1);
		foreach (Transform child in GameObject.Find (curTrackName).transform){
			child.GetComponent<SpriteRenderer> ().enabled = activation;
			child.GetComponent<PolygonCollider2D> ().enabled = activation;
		}
	}

	// troca de pista
	public void changeTrack(){
		enterTrackChange = false;

	

		activateTrack (track,false);
		track = (track + 1) % numOfTracks;
		curMilestones = "milestone ("+(track+1)+")";
		activateTrack (track,true);

		curIndv = 0;


		if (track == 1) {
			enterGenerationChange = true;
		} else {
			runGeneration = true;
			enterTrackChange = true;
			enterGenerationChange = false;
		}
			

	}

	// ======================= Controle de Populacao ============================

	// troca de individuo qnt ele morre
	public void changeIndv(){
		enterIndivChange = false;

		// Armazena pontuacao do ultimo individuo
		fitness (curIndv);

		Debug.Log ("Indv " + curIndv +" GEN " + numOfGenerations + "PTOS " + fit[curIndv]);
		printGen (curIndv);


		// 
		curIndv++;

		// Reinicializa individuo
		deadIndv = indv;
		indv = Instantiate (GameObject.Find ("creature"));
		Destroy (deadIndv);

		// inicializa componentes do novo individuo
		indv.GetComponent<SpriteRenderer> ().enabled = true;
		indv.GetComponent<BoxCollider2D> ().enabled = true;
		indv.GetComponent<Creature>().enabled = true;
		c = (Creature)indv.GetComponent (typeof(Creature));

		// reinicializa os marcadores
		resetMillestones ();
		enterIndivChange = true;
	}
	// ==========================================================================

	// ======================= Movimentacao =====================================
	// Movimenta individuo com base em seu gene
	public void move(GameObject crea,int ind){
		int sensor = c.checkSensors (); // verifica quais sensores estao ativos
		float mv = indvGen[ind][sensor]; // encontra resposta para determinado sensor no gene
		c.setMove (mv); // realiza movimentacao
	}
	// ==========================================================================


	// =============================== Algoritmo Genetco ========================

	public void printGen(int ind){
		string genes = "|";
		for (int i = 0; i < numOfGenes; i++)
			genes +=  indvGen[ind][i] + "|";
		Debug.Log("INDV"+ ind +" "+ genes);
	}

	// inicializa um gene com valores aleatorios
	public float[] createRandGene(){
		float[] gene = new float[numOfGenes];

		for(int i=0;i<numOfGenes;i++){
			float g = (float)rand.Next();
			int chance = rand.Next();
			if(chance % 2 == 0){
				gene [i] = (g) % genRange;
			}else{
				gene [i] = (g*(-1)) % genRange;
			}
		}
	
		return gene;
	}

	// Fase1 - iniciar populacao
	public void initPop(){
		indvGen = new float[numOfIndv][];


		for (int i = 0; i < numOfIndv; i++) {
			indvGen [i] = createRandGene (); 
			//Debug.Log ("["+ i + "]");
			//printGen (i);
		}

	}


	// Fase2 - avaliacao
	public void fitness(int indvIndex){				
		fit [indvIndex] += c.pontuation;
	}
		


	// Fase 3- Selecao = seleciona o melhor de todos e guarda seu valor
	public void selection(){
		enterSelection = false;
		int bestIndex = -1,bestValue = -1;
		float popAverage = 0;
		for (int i = 0; i < numOfIndv; i++) {
			popAverage += fit [i];
			if (fit [i] > bestValue) {
				bestIndex = i;
				bestValue = fit [i];
			}
		}
		popAverage /= numOfIndv;

		if (bestValue > bestOfAll[1][0]) {
			bestOfAll[0] = indvGen[bestIndex];
			bestOfAll[1][0] = bestValue;
		}
			
		bestFile.Write (bestOfAll[1][0]+";");
		popBestFile.Write (bestValue+";");
		popAvgFile.Write (popAverage+";");

		enterCrossover = true;
	}

	// Fase 4 - Crossover = cruzamento dos individuos por elitismo
	public void crossover(){											
		// pega o melhor de todos
		enterCrossover = false;
		System.Random rand = new System.Random ();

		for (int i = 0; i < numOfIndv; i++){
			for(int j=0;j<numOfGenes;j++){
					
				int coin = rand.Next() % 2;// sorteando na moeda de quem sera o gene

				if (!(coin == 0)) {	// troca o novo gene com o melhor de todos
					indvGen [i] [j] = bestOfAll [0] [j];
				} 
			}		
		}
		resetFit ();

		enterMutation = true;
	}

	// fase 5 - mutacao
	public void mutation(){
		enterMutation = false;
		// rand de um valor de 0 a numOfgenes q sorteia a posicao do gene q sera mutado
		// se resultar em um numero igual ao numOfGenes nenhuma mutacao eh feita
		for (int i = 0; i < numOfIndv; i++) {
			for(int j=0; j< numOfMutGen; j++){
				int genToMutate = rand.Next () % (numOfGenes + 1);

				if (genToMutate != numOfGenes) {
					if ((rand.Next () % 2) == 1) {
						indvGen [i] [genToMutate] = (indvGen [i] [genToMutate] + (int)mutationTax) % genRange;
					} else {
						indvGen [i] [genToMutate] = Mathf.Abs((indvGen [i] [genToMutate] - (int)mutationTax) % genRange);
					}
				}
			}
		}
		resetAll ();
	}


}
